@echo off
title Jira Dashboard
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0server.ps1"
pause
