# Jira Dashboard

A small local dashboard for your Jira (`jira.cogep.com`). No installs needed — it
runs on Windows PowerShell (built into Windows) and opens in your browser.

## What it does
- **4 tabs**: New tickets · Assigned to me · Waiting on others · My Work
- Tickets sorted by **status priority**: *Open* and *Waiting for Support* on top,
  closed/resolved sunk to the bottom (and hidden by default — toggle "Hide closed").
- **Expand any ticket** to read the latest reply (and earlier comments) inline.
- **Open / Reply in Jira** button opens the ticket in your browser (no replying from here).
- **Notifications + badges** for new and newly-assigned tickets (polls every 60s).
- **My Work** opens the Tempo page in your browser.

## One-time setup
1. Open `config.json`.
2. Paste your **Personal Access Token** into `"Token"`.
   - In Jira: your avatar → **Profile → Personal Access Tokens → Create token**.
3. Save.

That's it. The real filter IDs are already filled in:

| View | Filter ID | Jira filter name |
|------|-----------|------------------|
| New tickets | `10712` | SUP - L1 ticket queue |
| Assigned to me | `11419` | To watch |
| Waiting on others | `12004` | Waiting for Someone Else - JFT |

> Note: the numbers in the dashboard URLs (11310 / 11309 / 13001) are *gadget* IDs,
> not filter IDs — that was the original "bad request" cause. The IDs above are the
> actual saved filters those gadgets point to.

## Run it — two ways

### A) Tray mode (recommended — "always on")
Double-click **`Start Jira Dashboard (Tray).vbs`**.
- No window appears — a small blue dot lives in your **system tray** (bottom-right).
- It quietly polls Jira and pops a **balloon notification + sound** for new / newly
  assigned tickets *even when no browser tab is open*.
- The dot turns **red** when there are open "New" tickets.
- **Double-click the tray dot** → opens the dashboard in your browser.
- **Right-click the tray dot** → Open Dashboard · Check now · Mute sound · Quit.
- Click a balloon notification to jump straight to that ticket in Jira.

To start it automatically at login: press `Win+R`, type `shell:startup`, and drop a
shortcut to the `.vbs` file in that folder.

### B) Window mode (shows a console + logs)
Double-click **`Start Jira Dashboard.bat`** — opens a console and launches the
browser at `http://localhost:<port>`. Close the console to stop. Good for
troubleshooting since you can see any error messages.

> Run only **one** of the two at a time — they share the same port.

## Sound & notifications
- **In the browser UI**: tick **Sound** (a soft two-tone chime on new tickets) and
  **Notifications** (OS popups). Both remember your choice.
- **In tray mode**: sound is on by default (controlled by `"PlaySound"` in
  `config.json`); toggle it live via right-click → **Mute sound**.

## Notes & troubleshooting
- **"Couldn't load tickets"** → token is wrong/expired, or the filter IDs don't match
  yours. Re-check `config.json`.
- **Port in use** → change `"Port"` in `config.json` and restart.
- **SSL/certificate error** → if your Jira uses a self-signed cert, set
  `"IgnoreSslErrors": true` in `config.json`.
- **Basic auth instead of a PAT** → set `"AuthType": "Basic"`, put your username in
  `"BasicUser"`, and your password/token in `"Token"`.
- **Notifications** → tick the "Notifications" checkbox in the header and allow the
  browser prompt. Browser notifications fire even when the tab is in the background.
- **Images in comments** may not load if Jira requires a logged-in session — the text
  still shows; click "Open in Jira" to see everything.

## Files
| File | Purpose |
|------|---------|
| `config.json` | Your token, base URL, filter IDs, settings |
| `server.ps1` | Local server + Jira API proxy (keeps token off the browser) |
| `index.html` | The dashboard UI |
| `JiraTray.ps1` | System-tray always-on app (background notifications + sound) |
| `Start Jira Dashboard (Tray).vbs` | Tray launcher — no window (recommended) |
| `Start Jira Dashboard.bat` | Window launcher (shows console/logs) |
