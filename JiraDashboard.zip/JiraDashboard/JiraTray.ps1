# ============================================================================
#  Jira Dashboard - system tray (always-on) mode
#  - Runs the web server hidden in the background
#  - Lives in the Windows system tray
#  - Polls Jira for new / newly-assigned tickets and shows balloon + sound
#    even when no browser tab is open
# ============================================================================

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Web | Out-Null

$script:dir = $PSScriptRoot
$cfgPath = Join-Path $script:dir 'config.json'
$script:cfg  = Get-Content $cfgPath -Raw | ConvertFrom-Json
$script:base = $script:cfg.BaseUrl.TrimEnd('/')
$script:port = if ($script:cfg.Port) { [int]$script:cfg.Port } else { 8742 }

if ($script:cfg.IgnoreSslErrors) { [System.Net.ServicePointManager]::ServerCertificateValidationCallback = { $true } }
[System.Net.ServicePointManager]::SecurityProtocol = `
    [System.Net.SecurityProtocolType]::Tls12 -bor [System.Net.SecurityProtocolType]::Tls11 -bor [System.Net.SecurityProtocolType]::Tls

if ($script:cfg.AuthType -eq 'Basic') {
    $pair = "$($script:cfg.BasicUser):$($script:cfg.Token)"
    $script:auth = "Basic " + [System.Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($pair))
} else {
    $script:auth = "Bearer $($script:cfg.Token)"
}
$script:headers = @{ Authorization = $script:auth; Accept = 'application/json' }

$script:seen      = @{}      # key -> $true  (tickets we've already seen this run)
$script:baseline  = $false   # first poll establishes baseline silently
$script:muted     = -not [bool]$script:cfg.PlaySound
$script:lastKey   = $null
$script:serverProc = $null

# ---- background web server -------------------------------------------------
function Start-Server {
    if ($script:serverProc -and -not $script:serverProc.HasExited) { return }
    $script:serverProc = Start-Process powershell -PassThru -WindowStyle Hidden -ArgumentList @(
        '-NoProfile','-ExecutionPolicy','Bypass','-File',(Join-Path $script:dir 'server.ps1'),'-NoBrowser'
    )
}

# ---- tray icon (colored dot) ----------------------------------------------
function New-DotIcon([System.Drawing.Color]$color) {
    $bmp = New-Object System.Drawing.Bitmap 16,16
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = 'AntiAlias'
    $g.Clear([System.Drawing.Color]::Transparent)
    $g.FillEllipse((New-Object System.Drawing.SolidBrush $color), 1, 1, 14, 14)
    $g.Dispose()
    return [System.Drawing.Icon]::FromHandle($bmp.GetHicon())
}
$iconIdle = New-DotIcon ([System.Drawing.Color]::FromArgb(76,154,255))   # blue
$iconHot  = New-DotIcon ([System.Drawing.Color]::FromArgb(255,86,48))    # red/orange

$notify = New-Object System.Windows.Forms.NotifyIcon
$notify.Icon = $iconIdle
$notify.Text = 'Jira Dashboard'
$notify.Visible = $true

# ---- context menu ----------------------------------------------------------
$menu = New-Object System.Windows.Forms.ContextMenuStrip
$miOpen  = $menu.Items.Add('Open Dashboard')
$miCheck = $menu.Items.Add('Check now')
$menu.Items.Add('-') | Out-Null
$miMute  = New-Object System.Windows.Forms.ToolStripMenuItem 'Mute sound'
$miMute.CheckOnClick = $true
$miMute.Checked = $script:muted
$menu.Items.Add($miMute) | Out-Null
$menu.Items.Add('-') | Out-Null
$miQuit  = $menu.Items.Add('Quit')
$notify.ContextMenuStrip = $menu

function Open-Dashboard {
    Start-Server
    Start-Process ("http://localhost:{0}/" -f $script:port) | Out-Null
}

# ---- polling ---------------------------------------------------------------
function Get-OpenIssues([int]$filterId) {
    $jql = [System.Web.HttpUtility]::UrlEncode("filter = $filterId")
    $uri = "$($script:base)/rest/api/2/search?jql=$jql&maxResults=50&fields=summary,status"
    $r = Invoke-RestMethod -Uri $uri -Headers $script:headers -TimeoutSec 30
    $out = @()
    foreach ($it in $r.issues) {
        $cat = if ($it.fields.status -and $it.fields.status.statusCategory) { $it.fields.status.statusCategory.key } else { '' }
        if ($cat -ne 'done') {   # skip closed/resolved
            $out += [pscustomobject]@{ key = $it.key; summary = $it.fields.summary }
        }
    }
    return $out
}

function Invoke-Poll {
    try {
        $newOnes = @(Get-OpenIssues ([int]$script:cfg.Filters.new))
        $assigned = @(Get-OpenIssues ([int]$script:cfg.Filters.assigned))
    } catch {
        $notify.Text = 'Jira Dashboard - connection error'
        return
    }

    $fresh = @()
    foreach ($pair in @(@('New ticket',$newOnes), @('Assigned to you',$assigned))) {
        $label = $pair[0]
        foreach ($t in $pair[1]) {
            if (-not $script:seen.ContainsKey($t.key)) {
                $script:seen[$t.key] = $true
                if ($script:baseline) { $fresh += [pscustomobject]@{ label=$label; t=$t } }
            }
        }
    }
    $script:baseline = $true

    $notify.Text = ("Jira  -  New: {0}   Assigned: {1}" -f $newOnes.Count, $assigned.Count)
    $notify.Icon = if ($newOnes.Count -gt 0) { $iconHot } else { $iconIdle }

    if ($fresh.Count -gt 0) {
        $first = $fresh[0]
        $script:lastKey = $first.t.key
        $title = if ($fresh.Count -eq 1) { "$($first.label): $($first.t.key)" } else { "$($fresh.Count) new tickets" }
        $body  = if ($fresh.Count -eq 1) { $first.t.summary } else { ($fresh | ForEach-Object { $_.t.key }) -join ', ' }
        $notify.ShowBalloonTip(8000, $title, $body, [System.Windows.Forms.ToolTipIcon]::Info)
        if (-not $script:muted) { [System.Media.SystemSounds]::Asterisk.Play() }
    }
}

# ---- wire events -----------------------------------------------------------
$miOpen.add_Click({ Open-Dashboard })
$miCheck.add_Click({ Invoke-Poll })
$miMute.add_CheckedChanged({ $script:muted = $miMute.Checked })
$notify.add_DoubleClick({ Open-Dashboard })
$notify.add_BalloonTipClicked({
    if ($script:lastKey) { Start-Process ("{0}/browse/{1}" -f $script:base, $script:lastKey) | Out-Null }
})
$miQuit.add_Click({
    $script:timer.Stop()
    if ($script:serverProc -and -not $script:serverProc.HasExited) {
        try { Stop-Process -Id $script:serverProc.Id -Force -ErrorAction SilentlyContinue } catch {}
    }
    $notify.Visible = $false
    $notify.Dispose()
    [System.Windows.Forms.Application]::Exit()
})

# ---- start -----------------------------------------------------------------
Start-Server
$pollMs = [Math]::Max(20, [int]$script:cfg.PollSeconds) * 1000
$script:timer = New-Object System.Windows.Forms.Timer
$script:timer.Interval = $pollMs
$script:timer.add_Tick({ Invoke-Poll })
$script:timer.Start()

# initial baseline poll shortly after launch
$boot = New-Object System.Windows.Forms.Timer
$boot.Interval = 1500
$boot.add_Tick({ $boot.Stop(); Invoke-Poll })
$boot.Start()

$notify.ShowBalloonTip(3000, 'Jira Dashboard', 'Running in the tray. Double-click to open.', [System.Windows.Forms.ToolTipIcon]::None)
[System.Windows.Forms.Application]::Run((New-Object System.Windows.Forms.ApplicationContext))
