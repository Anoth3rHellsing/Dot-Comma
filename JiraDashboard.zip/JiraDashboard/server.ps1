# ============================================================================
#  Jira Dashboard - local server
#  Serves a small web UI and proxies requests to the self-hosted Jira REST API.
#  No external dependencies. Requires Windows PowerShell 5.1+ (built into Windows).
# ============================================================================
param([switch]$NoBrowser)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Web | Out-Null

# ---- Load config -----------------------------------------------------------
$scriptDir  = $PSScriptRoot
$configPath = Join-Path $scriptDir 'config.json'
if (-not (Test-Path $configPath)) {
    Write-Host "ERROR: config.json not found next to server.ps1" -ForegroundColor Red
    Read-Host "Press Enter to exit"; exit 1
}
$cfg = Get-Content $configPath -Raw | ConvertFrom-Json

$baseUrl = $cfg.BaseUrl.TrimEnd('/')
$port    = if ($cfg.Port) { [int]$cfg.Port } else { 8742 }

if ([string]::IsNullOrWhiteSpace($cfg.Token) -or $cfg.Token -like 'PASTE_*') {
    Write-Host ""
    Write-Host "  ==> Open config.json and paste your Jira Personal Access Token into \"Token\"." -ForegroundColor Yellow
    Write-Host "      (Jira > your avatar > Profile > Personal Access Tokens > Create token)" -ForegroundColor Yellow
    Write-Host ""
    Read-Host "Press Enter to exit"; exit 1
}

# ---- Optional: ignore SSL errors (only if your Jira cert is self-signed) ----
if ($cfg.IgnoreSslErrors) {
    [System.Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }
}
[System.Net.ServicePointManager]::SecurityProtocol = `
    [System.Net.SecurityProtocolType]::Tls12 -bor [System.Net.SecurityProtocolType]::Tls11 -bor [System.Net.SecurityProtocolType]::Tls

# ---- Build the auth header --------------------------------------------------
function Get-AuthHeader {
    if ($cfg.AuthType -eq 'Basic') {
        $pair  = "$($cfg.BasicUser):$($cfg.Token)"
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($pair)
        return "Basic " + [System.Convert]::ToBase64String($bytes)
    }
    return "Bearer $($cfg.Token)"
}
$headers = @{ Authorization = (Get-AuthHeader); Accept = 'application/json' }

# ---- Jira REST helpers ------------------------------------------------------
function Invoke-Jira([string]$path) {
    $uri = "$baseUrl/rest/api/2/$path"
    $attempts = 4
    $backoff  = 400, 800, 1500
    for ($i = 1; $i -le $attempts; $i++) {
        try {
            return Invoke-RestMethod -Uri $uri -Headers $headers -Method Get -TimeoutSec 40
        } catch {
            $code = if ($_.Exception.Response) { [int]$_.Exception.Response.StatusCode } else { 0 }
            # retry only transient failures (timeouts, 404 blips, 5xx); fail fast on auth errors
            $transient = ($code -eq 0 -or $code -eq 404 -or $code -ge 500)
            if (-not $transient -or $i -eq $attempts) { throw }
            Start-Sleep -Milliseconds $backoff[$i-1]
        }
    }
}

function Get-Tickets([string]$view) {
    $filterId = $cfg.Filters.$view
    if (-not $filterId) { throw "Unknown view '$view'." }
    $jql    = [System.Web.HttpUtility]::UrlEncode("filter = $filterId")
    $fields = 'summary,status,priority,assignee,reporter,issuetype,updated,created'
    $resp   = Invoke-Jira "search?jql=$jql&maxResults=100&fields=$fields"

    $list = @()
    foreach ($it in $resp.issues) {
        $f = $it.fields
        $list += [pscustomobject]@{
            key            = $it.key
            summary        = $f.summary
            status         = if ($f.status)   { $f.status.name } else { '' }
            statusCategory = if ($f.status -and $f.status.statusCategory) { $f.status.statusCategory.key } else { '' }
            priority       = if ($f.priority) { $f.priority.name } else { 'None' }
            priorityId     = if ($f.priority) { [int]$f.priority.id } else { 999 }
            assignee       = if ($f.assignee) { $f.assignee.displayName } else { 'Unassigned' }
            reporter       = if ($f.reporter) { $f.reporter.displayName } else { '' }
            issuetype      = if ($f.issuetype){ $f.issuetype.name } else { '' }
            updated        = $f.updated
            created        = $f.created
        }
    }
    return @{ issues = [object[]]@($list) }
}

function Get-IssueDetail([string]$key) {
    $resp = Invoke-Jira ("issue/" + $key + "?fields=summary,status,priority,assignee,reporter,description,comment&expand=renderedFields")

    $descHtml = ''
    if ($resp.renderedFields -and $resp.renderedFields.description) { $descHtml = $resp.renderedFields.description }
    elseif ($resp.fields.description) { $descHtml = "<pre>$([System.Web.HttpUtility]::HtmlEncode($resp.fields.description))</pre>" }

    $raw      = if ($resp.fields.comment)        { $resp.fields.comment.comments }        else { @() }
    $rendered = if ($resp.renderedFields -and $resp.renderedFields.comment) { $resp.renderedFields.comment.comments } else { @() }

    $comments = @()
    for ($i = 0; $i -lt $raw.Count; $i++) {
        $c = $raw[$i]
        $bodyHtml = if ($i -lt $rendered.Count -and $rendered[$i].body) { $rendered[$i].body }
                    else { "<pre>$([System.Web.HttpUtility]::HtmlEncode($c.body))</pre>" }
        $comments += [pscustomobject]@{
            author   = if ($c.author) { $c.author.displayName } else { 'Unknown' }
            created  = $c.created
            updated  = $c.updated
            bodyHtml = $bodyHtml
        }
    }
    # keep only the most recent 10 to bound payload size, newest last
    if ($comments.Count -gt 10) { $comments = $comments[($comments.Count-10)..($comments.Count-1)] }

    return @{
        key         = $resp.key
        summary     = $resp.fields.summary
        status      = if ($resp.fields.status) { $resp.fields.status.name } else { '' }
        descHtml    = $descHtml
        comments    = [object[]]@($comments)
    }
}

# ---- Tiny static + JSON HTTP server ----------------------------------------
function Send-Response($ctx, [int]$code, [string]$contentType, [byte[]]$bytes) {
    $ctx.Response.StatusCode  = $code
    $ctx.Response.ContentType = $contentType
    $ctx.Response.ContentLength64 = $bytes.Length
    $ctx.Response.OutputStream.Write($bytes, 0, $bytes.Length)
    $ctx.Response.OutputStream.Close()
}
function Send-Json($ctx, [int]$code, $obj) {
    $json  = $obj | ConvertTo-Json -Depth 12 -Compress
    Send-Response $ctx $code 'application/json; charset=utf-8' ([System.Text.Encoding]::UTF8.GetBytes($json))
}
function Send-Text($ctx, [int]$code, [string]$text, [string]$type) {
    Send-Response $ctx $code $type ([System.Text.Encoding]::UTF8.GetBytes($text))
}

$listener = New-Object System.Net.HttpListener
$prefix   = "http://localhost:$port/"
$listener.Prefixes.Add($prefix)
try {
    $listener.Start()
} catch {
    Write-Host "ERROR: could not start server on $prefix" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host "The port may be in use - change \"Port\" in config.json and retry." -ForegroundColor Yellow
    Read-Host "Press Enter to exit"; exit 1
}

Write-Host ""
Write-Host "  Jira Dashboard running at  $prefix" -ForegroundColor Green
Write-Host "  Jira:                      $baseUrl" -ForegroundColor DarkGray
Write-Host "  Close this window (or Ctrl+C) to stop." -ForegroundColor DarkGray
Write-Host ""
if (-not $NoBrowser) { Start-Process $prefix | Out-Null }

while ($listener.IsListening) {
    $ctx = $listener.GetContext()
    try {
        $path  = $ctx.Request.Url.AbsolutePath
        $query = [System.Web.HttpUtility]::ParseQueryString($ctx.Request.Url.Query)

        switch -Regex ($path) {
            '^/$|^/index\.html$' {
                $htmlPath = Join-Path $scriptDir 'index.html'
                $html = Get-Content $htmlPath -Raw -Encoding UTF8
                Send-Text $ctx 200 $html 'text/html; charset=utf-8'
                break
            }
            '^/api/config$' {
                Send-Json $ctx 200 @{
                    baseUrl              = $baseUrl
                    pollSeconds          = [int]$cfg.PollSeconds
                    tempoMyWorkUrl       = $cfg.TempoMyWorkUrl
                    highPriorityStatuses = [string[]]@($cfg.HighPriorityStatuses)
                    playSound            = [bool]$cfg.PlaySound
                }
                break
            }
            '^/api/tickets$' {
                $view = $query['view']
                try   { Send-Json $ctx 200 (Get-Tickets $view) }
                catch { Send-Json $ctx 502 @{ error = $_.Exception.Message } }
                break
            }
            '^/api/issue$' {
                $key = $query['key']
                try   { Send-Json $ctx 200 (Get-IssueDetail $key) }
                catch { Send-Json $ctx 502 @{ error = $_.Exception.Message } }
                break
            }
            default {
                Send-Text $ctx 404 'Not found' 'text/plain; charset=utf-8'
            }
        }
    } catch {
        try { Send-Json $ctx 500 @{ error = $_.Exception.Message } } catch {}
    }
}
